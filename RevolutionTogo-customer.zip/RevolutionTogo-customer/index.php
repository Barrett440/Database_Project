<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Revolution ToGo</title>

	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
<!--

Template 2076 Zentro

http://www.tooplate.com/view/2076-zentro

-->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
    <script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<!-- preloader section -->
<section class="preloader">
	<div class="sk-spinner sk-spinner-pulse"></div>
</section>

<!-- navigation section -->
<section class="navbar navbar-default navbar-fixed-top" role="navigation">
	<div class="container">
		<div class="navbar-header">
			<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
				<span class="icon icon-bar"></span>
			</button>
			<a href="#" class="navbar-brand">REVOLUTION</a>
		</div>
		<div class="collapse navbar-collapse">
			<ul class="nav navbar-nav navbar-right">
				<li><a href="#home" onclick="location.href='#home'" class="smoothScroll">HOME</a></li>
				<li><a href="#gallery" onclick="location.href='#gallery'" class="smoothScroll">FOOD GALLERY</a></li>
				<li><a href="#menu" onclick="location.href='#menu'" class="smoothScroll">MENU</a></li>
                <li><a href="#team" onclick="location.href='#team'" class="smoothScroll">CHEFS</a></li>
                <li><a href="#contact" onclick="location.href='#contact'" class="smoothScroll">ORDER</a></li>
			</ul>
		</div>
	</div>
</section>


<!-- home section -->
<section id="home" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12">
				<h1>REVOLUTION RESTAURANT</h1>
				<h1>CARRYOUT AVAILABLE!</h1>
				<a href="#contact" onclick="location.href='#contact'" class="smoothScroll btn btn-default">ORDER NOW</a>
			</div>
		</div>
	</div>		
</section>



<!-- gallery section -->
<section id="gallery" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
				<h1 class="heading">Food Gallery</h1>
				<hr>
			</div>
			<div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.3s">
				<a href="images/gallery-img1.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img1.jpg" alt="gallery img"></a>
				<div>
					<h3>Shrimp with Tofu $10.95</h3>
					<span>Seafood / Shrimp / Tofu</span>
				</div>
				<a href="images/gallery-img2.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img2.jpg" alt="gallery img"></a>
				<div>
					<h3>Vegetable Egg Roll $2.95</h3>
					<span>Tomato / Mushroom / Pepper</span>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
				<a href="images/gallery-img3.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img3.jpg" alt="gallery img"></a>
				<div>
					<h3>Pork with Garlic Sauce $14.95</h3>
					<span>Bread / Pork / Garlic</span>
				</div>
			</div>
			<div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.9s">
				<a href="images/gallery-img4.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img4.jpg" alt="gallery img"></a>
				<div>
					<h3>Vegetable Chicken $10.95</h3>
					<span>Chicken / Egg / Green</span>
				</div>
				<a href="images/gallery-img5.jpg" data-lightbox-gallery="zenda-gallery"><img src="images/gallery-img5.jpg" alt="gallery img"></a>
				<div>
					<h3>Marinated Beef Brisket $20.95</h3>
					<span>Beef / Cheese / Green</span>
				</div>
			</div>
		</div>
	</div>
</section>


<!-- menu section -->
<section id="menu" class="parallax-section">
	<div class="container">
		<div class="row">
			<div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
				<h1 class="heading">Menu</h1>
				<hr>
			</div>
            <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                <h4><span>

			<?php

            include "config.php";

            for ($x = 1; $x <= 11; $x++){

                $sql_c = "SELECT categoryName FROM menuCategories WHERE categoryID=' ". $x. " '";
                if ($result_c = $con->query($sql_c)) {

                    while($row = $result_c->fetch_assoc()) {
                        echo "<br><br><h3>" . $row['categoryName'] ."</h3><br><br>";

                        //"Item: " . $row["itemName"]. " - Price: " . $row["price"]. "<br>";
                    }
                }

                $sql = "SELECT * FROM menuItem WHERE categoryID=' ". $x. " '";
                if ($result = $con->query($sql)) {

                    while($row = $result->fetch_assoc()) {
                        echo "<h4>" .$row['itemID'] . " | ". $row['itemName'] . " | ". $row['price']."</h4><br>";
                        //"Item: " . $row["itemName"]. " - Price: " . $row["price"]. "<br>";
                    }
                }


            }



			?>
            </span></h4>
        </div>

		</div>
	</div>
</section>


<!-- team section -->
<section id="team" class="parallax-section">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                <h1 class="heading">Meet with Chefs</h1>
                <hr>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.3s">
                <img src="images/team1.jpg" class="img-responsive center-block" alt="team img">
                <h4>Jingwen Zhong</h4>
                <h3>Main Chef</h3>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <img src="images/team2.jpg" class="img-responsive center-block" alt="team img">
                <h4>Pin Li</h4>
                <h3>Tofu Specialist</h3>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.9s">
                <img src="images/team3.jpg" class="img-responsive center-block" alt="team img">
                <h4>Hao Ma</h4>
                <h3>Beef Specialist</h3>
            </div>
        </div>
    </div>
</section>


<!-- order section -->
<section id="contact" class="parallax-section">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-1 col-md-10 col-sm-12 text-center">
                <h1 class="heading">ORDER PICKUP</h1>
                <hr>
            </div>

            <div class="col-md-offset-1 col-md-10 col-sm-12 wow fadeIn" data-wow-delay="0.9s">
                <form action="confirm.php" method="post">

                    <!-- Phone Number input -->
                    <div class="col-md-6 col-sm-6">
                        <input name="phone" type="tel" class="form-control" id="phone"
                               pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}"
                               required
                               placeholder="Phone, Format: 123-456-7890">
                    </div>

                    <br>

                    <!-- Pickup Time input -->
                    <div class="col-md-6 col-sm-6">
                        <label for="pickuptime">Choose Pickup Time:  </label>
                        <input id="pickuptime" type="datetime-local" name="pickuptime"
                               min="<?php echo date('Y-m-d')."T".date('H:i');?>"
                               max="2050-06-30T16:30"
                               value="<?php echo date('Y-m-d')."T".date('H:i');?>"
                               pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}" required>

                        <span class="validity"></span>
                    </div>

                    <br>



                    <!-- Dish & Quantity input -->
                    <div class="col-md-6 col-sm-6">
                        <input name="itemID[]" type="number" class="form-control"
                               min="1" max="
                        <?php

                        include "config.php";


                        $sql = "SELECT MAX(itemID) AS m FROM menuItem";
                        if ($result = $con->query($sql)) {

                            while($row = $result->fetch_assoc()) {
                                $max_itemID = $row['m'];
                                echo $max_itemID;
                            }
                        }

                        ?>"
                               required
                               placeholder="Please type in the dish ID number">
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <input name="itemQ[]" type="number" class="form-control"
                               min="0" max="100"
                               required
                               placeholder="Please indicate the quantity you need for this dish">
                    </div>

                    <br>
                    <div id="timeCont"></div>
                    <div class="col-md-offset-3 col-md-6 col-sm-offset-3 col-sm-6">
                    <button type="button" class="btn blue" id="fatBtn">Click Here to Add Dish</button>
                        <br>
                    </div>

                    <script type="text/javascript">

                        $("#fatBtn").click(function() {

                            var htm = "";
                            htm += '<div class=\"col-md-6 col-sm-6\">';
                            htm += '<input name="itemID[]" type="number" class="form-control"  min="1" max="<?php echo $max_itemID; ?>" required placeholder="Please type in the dish ID number">';
                            htm += "</div>";

                            htm += '<div class=\"col-md-6 col-sm-6\">';
                            htm += '<input name="itemQ[]" type="number" class="form-control" min="1" max="100" required placeholder="Please indicate the quantity you need for this dish">';
                            htm += "</div>";

                            $('#timeCont').append(htm);

                        });

                    </script>


                    <!-- Message input -->
                    <div class="col-md-12 col-sm-12">
                        <textarea name="message" rows="8" class="form-control" id="message"
                                  placeholder="Special Instruction -- Dressing on the side, or have another request?"></textarea>
                    </div>


                    <div class="col-md-offset-3 col-md-6 col-sm-offset-3 col-sm-6">
                        <input name="submit" type="submit" class="form-control" id="submit" value="PLACE PICKUP ORDER NOW">
                    </div>
                </form>
            </div>
            <div class="col-md-2 col-sm-1"></div>
        </div>
    </div>
</section>


<!-- footer section -->
<footer class="parallax-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <h2 class="heading">Contact Info.</h2>
                <div class="ph">
                    <p><i class="fa fa-phone"></i> Phone</p>
                    <h4>724-799-3689</h4>
                </div>
                <div class="address">
                    <p><i class="fa fa-map-marker"></i> Our Location</p>
                    <h4>382 Jefferson Rd, Rochester, NY 14623, USA</h4>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <h2 class="heading">Open Hours</h2>
                <p>Sunday <span>10:30 AM - 10:00 PM</span></p>
                <p>Mon-Fri <span>9:00 AM - 8:00 PM</span></p>
                <p>Saturday <span>11:30 AM - 10:00 PM</span></p>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <h2 class="heading">Follow Us</h2>
                <ul class="social-icon">
                    <li><a href="https://www.facebook.com/RevolutionChineseROC" class="fa fa-facebook wow bounceIn" data-wow-delay="0.3s"></a></li>
                    <li><a href="#" class="fa fa-twitter wow bounceIn" data-wow-delay="0.6s"></a></li>
                    <li><a href="https://pin-li.github.io/" class="fa fa-github wow bounceIn" data-wow-delay="0.9s"></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>


<!-- copyright section -->
<section id="copyright">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <h3>REVOLUTION</h3>
                <p>Copyright © Zantro


            </div>
        </div>
    </div>
</section>

<!-- JAVASCRIPT JS FILES -->	
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.parallax.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>
