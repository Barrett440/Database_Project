<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Revolution ToGo</title>

    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <!--

    Template 2076 Zentro

    http://www.tooplate.com/view/2076-zentro

    -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/nivo-lightbox.css">
    <link rel="stylesheet" href="css/nivo_themes/default/default.css">
    <link rel="stylesheet" href="css/style.css">
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,500' rel='stylesheet' type='text/css'>
    <script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.bootcss.com/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>

<!-- preloader section -->
<section class="preloader">
    <div class="sk-spinner sk-spinner-pulse"></div>
</section>

<!-- navigation section -->
<section class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon icon-bar"></span>
                <span class="icon icon-bar"></span>
                <span class="icon icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand">REVOLUTION</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#home" onclick="location.href='index.php#home'" class="smoothScroll">HOME</a></li>
                <li><a href="#gallery" onclick="location.href='index.php#gallery'" class="smoothScroll">FOOD GALLERY</a></li>
                <li><a href="#menu" onclick="location.href='index.php#menu'" class="smoothScroll">MENU</a></li>
                <li><a href="#team" onclick="location.href='index.php#team'" class="smoothScroll">CHEFS</a></li>
                <li><a href="#contact" onclick="location.href='index.php#contact'" class="smoothScroll">ORDER</a></li>
            </ul>
        </div>
    </div>
</section>





<!-- menu section -->
<section id="menu" class="parallax-section">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                <h1 class="heading">Thank you!</h1>
                <hr>
            </div>
            <div class="col-md-offset-2 col-md-8 col-sm-12 text-center">
                <?php
                include "config.php";

                date_default_timezone_set("America/New_York");
                $time = date("m/d/Y h:ia");
                $sql_insert = "INSERT INTO orders (estPickupTime,customizedNote,phoneNumber,orderTime) VALUES ('$_POST[pickuptime]', '$_POST[message]', '$_POST[phone]', '$time')";

                if ($con->query($sql_insert) === TRUE) {
                    $order_num = mysqli_insert_id($con);
                } else {
                    echo "<br>Error adding order " . $con->error;
                    echo "Please return to the previous page.";
                }


                $item_array = $_POST['itemID'];
                $itemQ_array = $_POST['itemQ'];
                for ($i = 0; $i <= count($item_array)-1; $i++) {
                    $sql_insert_2 = "INSERT INTO orderIncludes (orderID, menuItemID, quantity) VALUES ('$order_num', '$item_array[$i]', '$itemQ_array[$i]')";
                    if ($con->query($sql_insert_2) === FALSE) {
                        echo "<br>Error adding values " . $con->error;
                        echo "Will return to the previous page in 2 seconds";
                        header('refresh:2; url=index.php');
                    } else {

                        echo "<h5>...Successfully added ". $item_array[$i] . " * Quantity" . $itemQ_array[$i] ."...</h5><br>";
                    }

                }

                echo "<h3>Thank you! Your order has been placed.<br>Your order number is:</h3><br><br>";
                echo "<h2>".$order_num."</h2><br><br>";
                echo "<h3>If you would like any change or to cancel your order,<br>please feel free to call our restaurant.<br>Our phone number and social media are shown below.</h3><br><br>";


                ?>


                <?php
                $con->close();
                ?>


            </div>

        </div>
    </div>
</section>



<!-- footer section -->
<footer class="parallax-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <h2 class="heading">Contact Info.</h2>
                <div class="ph">
                    <p><i class="fa fa-phone"></i> Phone</p>
                    <h4>724-799-3689</h4>
                </div>
                <div class="address">
                    <p><i class="fa fa-map-marker"></i> Our Location</p>
                    <h4>382 Jefferson Rd, Rochester, NY 14623, USA</h4>
                </div>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <h2 class="heading">Open Hours</h2>
                <p>Sunday <span>10:30 AM - 10:00 PM</span></p>
                <p>Mon-Fri <span>9:00 AM - 8:00 PM</span></p>
                <p>Saturday <span>11:30 AM - 10:00 PM</span></p>
            </div>
            <div class="col-md-4 col-sm-4 wow fadeInUp" data-wow-delay="0.6s">
                <h2 class="heading">Follow Us</h2>
                <ul class="social-icon">
                    <li><a href="https://www.facebook.com/RevolutionChineseROC" class="fa fa-facebook wow bounceIn" data-wow-delay="0.3s"></a></li>
                    <li><a href="#" class="fa fa-twitter wow bounceIn" data-wow-delay="0.6s"></a></li>
                    <li><a href="https://pin-li.github.io/" class="fa fa-github wow bounceIn" data-wow-delay="0.9s"></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>


<!-- copyright section -->
<section id="copyright">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12">
                <h3>REVOLUTION</h3>
                <p>Copyright © Zantro


            </div>
        </div>
    </div>
</section>

<!-- JAVASCRIPT JS FILES -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.parallax.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>
